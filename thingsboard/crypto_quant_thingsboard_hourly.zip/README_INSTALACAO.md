# Integração Crypto Quant Monitor 2.4 + ThingsBoard

## O que faz
A cada hora, o systemd executa o scanner e, somente se ele terminar com sucesso,
executa `thingsboard_publisher.py`. O publisher lê o SQLite e envia telemetria
por HTTP POST para `/api/v1/<DEVICE_ACCESS_TOKEN>/telemetry`.

## 1. Criar dispositivo no ThingsBoard
1. Acesse `http://127.0.0.1:8080` (ou a URL usada na sua instalação).
2. Vá em Entities > Devices > Add new device.
3. Nome sugerido: `Crypto Quant Monitor`.
4. Abra o dispositivo, vá em Credentials e copie o Access Token.

## 2. Instalar os arquivos
Copie `thingsboard_publisher.py` para `/home/pi4/crypto-quant-monitor/`.
Copie `.thingsboard.env.example` para `.thingsboard.env` e preencha TB_TOKEN.
Proteja o token:
```bash
chmod 600 /home/pi4/crypto-quant-monitor/.thingsboard.env
```
Confirme a dependência:
```bash
cd /home/pi4/crypto-quant-monitor
source .venv/bin/activate
pip install requests
```

## 3. Testar POST manualmente (sem executar scanner)
```bash
cd /home/pi4/crypto-quant-monitor
set -a
source .thingsboard.env
set +a
.venv/bin/python thingsboard_publisher.py
```
Confira os dados em Devices > Crypto Quant Monitor > Latest telemetry.

## 4. Instalar agendamento horário
Copie `crypto-monitor.service` e `crypto-monitor.timer` para `/etc/systemd/system/`:
```bash
sudo cp crypto-monitor.service /etc/systemd/system/
sudo cp crypto-monitor.timer /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now crypto-monitor.timer
```
O timer agenda a execução no início de cada hora, com pequeno atraso aleatório.
A execução é sequencial: scanner primeiro, POST depois.

## 5. Verificar
```bash
systemctl list-timers crypto-monitor.timer
sudo systemctl start crypto-monitor.service
sudo systemctl status crypto-monitor.service
journalctl -u crypto-monitor.service -n 100 --no-pager
tail -n 50 logs/thingsboard_publisher.log
```

## Atenção: evitar execução duplicada
Antes de ativar o timer, desative qualquer cron/loop/serviço antigo que também execute
`scanner.py`. Se houver um scanner iniciado com `nohup`, localize-o:
```bash
pgrep -af 'python.*scanner.py'
```
Finalize somente o processo antigo identificado, antes de deixar o systemd como único agendador.

## Métricas enviadas
Globais: status/duração da execução, ativos aprovados/selecionados/completos/parciais,
falhas, candles inseridos, candles totais, sinais salvos, backfill, lacunas, resultados
pendentes/observados e médias de movimento alinhado por horizonte.
Por ativo: `signal_SYMBOL`, `price_SYMBOL`, `volume_24h_SYMBOL`,
`spread_pct_SYMBOL` e `change_24h_pct_SYMBOL`.
Auditoria do histórico: contagem, alvo de 500 candles, lacunas e cobertura média por timeframe.

## Observações
- O token é credencial: não o compartilhe em prints/logs e mantenha o arquivo com chmod 600.
- `127.0.0.1:8080` presume ThingsBoard HTTP local padrão. Se sua instalação usa HTTPS,
  proxy reverso ou outra porta, ajuste TB_URL.
- `ExecStartPost` só roda se o scanner finalizar com sucesso.
- O serviço é `oneshot`; o timer agenda novas execuções. Não é um processo contínuo.
- A API de telemetria aceita HTTP 200 ou 204 como sucesso.
